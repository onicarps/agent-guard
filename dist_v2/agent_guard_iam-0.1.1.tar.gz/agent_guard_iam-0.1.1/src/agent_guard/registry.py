"""Agent registry — stores and manages agent identities and policies."""
from __future__ import annotations

import asyncio
import hashlib
import json
from typing import Any

import aiosqlite

from .policies import AgentPolicy, AuditEntry, PermissionEffect, ResourcePermission


DB_SCHEMA = """
CREATE TABLE IF NOT EXISTS agents (
    agent_id TEXT PRIMARY KEY,
    agent_name TEXT NOT NULL UNIQUE,
    role TEXT DEFAULT 'default',
    policy_json TEXT NOT NULL,
    parent_agent_id TEXT,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    entry_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    agent_name TEXT NOT NULL,
    resource TEXT NOT NULL,
    operation TEXT,
    effect TEXT NOT NULL,
    timestamp REAL NOT NULL,
    metadata_json TEXT DEFAULT '{}',
    previous_hash TEXT DEFAULT '',
    chain_hash TEXT DEFAULT '',
    FOREIGN KEY (agent_id) REFERENCES agents(agent_id)
);

CREATE INDEX IF NOT EXISTS idx_audit_agent ON audit_log(agent_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp);
"""


class AgentRegistry:
    """SQLite-backed agent registry."""

    def __init__(self, db_path: str = "agent_guard.db"):
        self.db_path = db_path
        self._db: aiosqlite.Connection | None = None
        self._audit_lock = asyncio.Lock()

    def _require_connected(self) -> None:
        """Fail loudly if methods are called before connect()."""
        if self._db is None:
            raise RuntimeError(
                "AgentRegistry not connected; call await registry.connect() first"
            )

    async def connect(self) -> None:
        """Initialize database connection and schema."""
        self._db = await aiosqlite.connect(self.db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.executescript(DB_SCHEMA)
        for column_ddl in (
            "ALTER TABLE audit_log ADD COLUMN previous_hash TEXT DEFAULT ''",
            "ALTER TABLE audit_log ADD COLUMN chain_hash TEXT DEFAULT ''",
        ):
            try:
                await self._db.execute(column_ddl)
            except Exception:
                pass
        await self._db.commit()

    async def close(self) -> None:
        """Close database connection."""
        if self._db:
            await self._db.close()
            self._db = None

    async def register_agent(self, policy: AgentPolicy) -> str:
        """Register a new agent with a policy. Returns agent_id."""
        self._require_connected()
        import time
        now = time.time()
        await self._db.execute(
            "INSERT INTO agents (agent_id, agent_name, role, policy_json, parent_agent_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (policy.agent_id, policy.agent_name, policy.role, policy.model_dump_json(), policy.parent_agent_id, now, now)
        )
        await self._db.commit()
        return policy.agent_id

    async def get_agent(self, agent_id: str) -> AgentPolicy | None:
        """Get agent policy by ID."""
        self._require_connected()
        cursor = await self._db.execute("SELECT policy_json FROM agents WHERE agent_id = ?", (agent_id,))
        row = await cursor.fetchone()
        if row:
            return AgentPolicy.model_validate_json(row["policy_json"])
        return None

    async def get_agent_by_name(self, agent_name: str) -> AgentPolicy | None:
        """Get agent policy by name."""
        self._require_connected()
        cursor = await self._db.execute("SELECT policy_json FROM agents WHERE agent_name = ?", (agent_name,))
        row = await cursor.fetchone()
        if row:
            return AgentPolicy.model_validate_json(row["policy_json"])
        return None

    async def update_policy(self, agent_id: str, policy: AgentPolicy) -> bool:
        """Update an agent's policy."""
        self._require_connected()
        import time
        cursor = await self._db.execute(
            "UPDATE agents SET policy_json = ?, role = ?, updated_at = ? WHERE agent_id = ?",
            (policy.model_dump_json(), policy.role, time.time(), agent_id)
        )
        await self._db.commit()
        return cursor.rowcount > 0

    async def delete_agent(self, agent_id: str) -> bool:
        """Delete an agent."""
        self._require_connected()
        cursor = await self._db.execute("DELETE FROM agents WHERE agent_id = ?", (agent_id,))
        await self._db.commit()
        return cursor.rowcount > 0

    async def list_agents(self) -> list[dict[str, Any]]:
        """List all registered agents."""
        self._require_connected()
        cursor = await self._db.execute("SELECT agent_id, agent_name, role, created_at FROM agents")
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]

    async def check_permission(self, agent_id: str, resource: str, operation: str | None = None) -> PermissionEffect:
        """Check if an agent has permission for a resource."""
        self._require_connected()
        policy = await self.get_agent(agent_id)
        if not policy:
            return PermissionEffect.DENY
        inherited = await self.resolve_permissions(agent_id, _skip_self=True)
        return policy.check_permission(resource, operation, inherited)

    async def resolve_permissions(
        self,
        agent_id: str,
        _skip_self: bool = False,
    ) -> list[ResourcePermission]:
        """Walk the parent chain and collect inherited permissions.

        Returns merged list ordered from most-specific (self) to least-specific
        (root ancestor). Cycles are broken via a visited set, and missing
        ancestors are skipped silently.
        """
        merged: list[ResourcePermission] = []
        visited: set[str] = set()
        current_id: str | None = agent_id
        first = True
        while current_id and current_id not in visited:
            visited.add(current_id)
            policy = await self.get_agent(current_id)
            if not policy:
                break
            if not (first and _skip_self):
                merged.extend(policy.permissions)
            first = False
            current_id = policy.parent_agent_id
        return merged

    async def log_audit(self, entry: AuditEntry) -> None:
        """Write an audit log entry, linking it into the tamper-evident chain."""
        self._require_connected()
        async with self._audit_lock:
            cursor = await self._db.execute(
                "SELECT chain_hash FROM audit_log ORDER BY timestamp DESC, entry_id DESC LIMIT 1"
            )
            prev_row = await cursor.fetchone()
            previous_hash = prev_row["chain_hash"] if prev_row else ""

            metadata_json = json.dumps(entry.metadata)
            chain_hash = _compute_chain_hash(
                entry_id=entry.entry_id,
                agent_id=entry.agent_id,
                resource=entry.resource,
                operation=entry.operation,
                effect=entry.effect.value,
                timestamp=entry.timestamp,
                metadata_json=metadata_json,
                previous_hash=previous_hash,
            )

            await self._db.execute(
                "INSERT INTO audit_log (entry_id, agent_id, agent_name, resource, operation, effect, timestamp, metadata_json, previous_hash, chain_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    entry.entry_id,
                    entry.agent_id,
                    entry.agent_name,
                    entry.resource,
                    entry.operation,
                    entry.effect.value,
                    entry.timestamp,
                    metadata_json,
                    previous_hash,
                    chain_hash,
                ),
            )
            await self._db.commit()
            entry.previous_hash = previous_hash

    async def verify_chain(self) -> bool:
        """Recompute every entry's hash and verify the chain is intact."""
        self._require_connected()
        cursor = await self._db.execute(
            "SELECT entry_id, agent_id, resource, operation, effect, timestamp, metadata_json, previous_hash, chain_hash FROM audit_log ORDER BY timestamp ASC, entry_id ASC"
        )
        rows = await cursor.fetchall()
        expected_prev = ""
        for row in rows:
            if row["previous_hash"] != expected_prev:
                return False
            recomputed = _compute_chain_hash(
                entry_id=row["entry_id"],
                agent_id=row["agent_id"],
                resource=row["resource"],
                operation=row["operation"],
                effect=row["effect"],
                timestamp=row["timestamp"],
                metadata_json=row["metadata_json"],
                previous_hash=row["previous_hash"],
            )
            if recomputed != row["chain_hash"]:
                return False
            expected_prev = row["chain_hash"]
        return True

    async def get_audit_log(self, agent_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        """Get audit log entries, optionally filtered by agent.
        
        Returns entries with metadata_json parsed into a dict.
        """
        self._require_connected()
        if agent_id:
            cursor = await self._db.execute(
                "SELECT * FROM audit_log WHERE agent_id = ? ORDER BY timestamp DESC LIMIT ?",
                (agent_id, limit)
            )
        else:
            cursor = await self._db.execute(
                "SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ?",
                (limit,)
            )
        rows = await cursor.fetchall()
        result = []
        for row in rows:
            entry = dict(row)
            # Parse metadata_json string into dict
            if isinstance(entry.get("metadata_json"), str):
                try:
                    entry["metadata_json"] = json.loads(entry["metadata_json"])
                except (json.JSONDecodeError, TypeError):
                    entry["metadata_json"] = {}
            result.append(entry)
        return result


def _compute_chain_hash(
    *,
    entry_id: str,
    agent_id: str,
    resource: str,
    operation: str | None,
    effect: str,
    timestamp: float,
    metadata_json: str,
    previous_hash: str,
) -> str:
    payload = "|".join(
        [
            entry_id,
            agent_id,
            resource,
            operation or "",
            effect,
            repr(timestamp),
            metadata_json,
            previous_hash,
        ]
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
