#!/usr/bin/env python3
"""Upload to PyPI with verification. Token is read from env, not hardcoded."""
import subprocess, sys, os, urllib.request, json

token = os.environ.get("PYPI_API_TOKEN")
if not token:
    # Fallback: read from .env file
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    with open(env_path) as f:
        for line in f:
            k, v = line.strip().split("=", 1) if "=" in line else ("", "")
            if k == "PYPI_API_TOKEN":
                token = v
                break

if not token:
    print("ERROR: PYPI_API_TOKEN not found in env or .env file")
    sys.exit(1)

print(f"Token length: {len(token)}")

twine = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".venv", "bin", "twine")
dist = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dist_new")
wheel = os.path.join(dist, "agent_guard_iam-0.1.0-py3-none-any.whl")
sdist = os.path.join(dist, "agent_guard_iam-0.1.0.tar.gz")

result = subprocess.run(
    [twine, "upload", "--username", "__token__", "--password", token, wheel, sdist],
    capture_output=True, text=True
)

print(result.stdout)
if result.stderr:
    print("STDERR:", result.stderr)
print("Exit:", result.returncode)

if result.returncode != 0:
    sys.exit(1)

print("\nVerifying on PyPI...")
req = urllib.request.Request("https://pypi.org/pypi/agent-guard-iam/json")
with urllib.request.urlopen(req) as resp:
    data = json.loads(resp.read())
    v = data["info"]["version"]
    print(f"PyPI version: {v}")
    assert v == "0.1.0"
    print("Verified!")
